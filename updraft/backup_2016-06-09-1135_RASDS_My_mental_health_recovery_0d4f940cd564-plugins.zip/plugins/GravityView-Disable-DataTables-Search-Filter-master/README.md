GravityView - Disable DataTables Search Filter
============================================

When using the DataTables Extension, Views are displayed with a search input provided by the DataTables script. If you are also using the GravityView Search Bar, you may not want both of these enabled.

To disable the DataTables search input, download and install this plugin. Once the plugin is installed and activated, you will no longer see the DataTables search input.
