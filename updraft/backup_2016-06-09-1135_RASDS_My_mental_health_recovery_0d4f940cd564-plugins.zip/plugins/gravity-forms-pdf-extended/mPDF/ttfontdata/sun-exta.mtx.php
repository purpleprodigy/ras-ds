<?php
$name='Sun-ExtA';
$type='TTF';
$desc=array (
  'Ascent' => 930,
  'Descent' => -141,
  'CapHeight' => 930,
  'Flags' => 4,
  'FontBBox' => '[-973 -301 2074 1078]',
  'ItalicAngle' => 0,
  'StemV' => 87,
  'MissingWidth' => 1000,
);
$up=-86;
$ut=47;
$ttffile='G:/Blue Liquid Designs/4) BLUE LIQUID DESIGNS/12) FTP/2.2.0/wp-content/plugins/gravity-forms-pdf-extended/mPDF/ttfonts/Sun-ExtA.ttf';
$TTCfontID='0';
$originalsize=22993540;
$sip=false;
$smp=false;
$BMPselected=false;
$fontkey='sun-exta';
$panose=' 0 0 2 1 6 0 3 1 1 1 1 1';
$kerninfo=array (
);
$haskerninfo=true;
$unAGlyphs=false;
?>