<?php

			if(!defined("PDF_EXTENDED_VERSION"))
			{
				return;
			}

		