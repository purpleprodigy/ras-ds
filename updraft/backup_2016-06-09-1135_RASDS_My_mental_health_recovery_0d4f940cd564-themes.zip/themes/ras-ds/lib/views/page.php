<div class="row-white pad-y-5">
	<div class="container-fluid">
		<div class="row">
			<div class="col-sm-8 col-sm-offset-2">
				<h2 class="mar-0 mar-b-4 text-9"><?php esc_html_e( $page->post_title ); ?></h2>
				<?php echo wpautop( $content ); ?>
			</div>
		</div>
	</div>
</div>


