<div class="row-white pad-y-5">
	<div class="container-fluid">
		<div class="row">
			<div class="col-sm-12">
				<?php echo wpautop( $content ); ?>
			</div>
		</div>
	</div>
</div>