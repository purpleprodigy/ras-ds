$(function() {
	$(document).responsinav({
		 breakpoint : 930
		});
});
